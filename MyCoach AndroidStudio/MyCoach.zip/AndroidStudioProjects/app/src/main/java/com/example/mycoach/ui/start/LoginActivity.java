package com.example.mycoach.ui.start;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mycoach.R;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;



    public class LoginActivity extends AppCompatActivity {

        private static final String TAG = "LoginActivity";

        private EditText emailEditText, passwordEditText;
        private Button loginButton;

        private FirebaseFirestore db;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_login);

            db = FirebaseFirestore.getInstance();

            emailEditText = findViewById(R.id.login_email_edit_text);
            passwordEditText = findViewById(R.id.login_password_edit_text);
            loginButton = findViewById(R.id.login_button);

            loginButton.setOnClickListener(view -> loginUser());
        }

        private void loginUser() {
            String email = emailEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Заполните все поля!", Toast.LENGTH_SHORT).show();
                return;
            }

            // !!! ЗАМЕНИТЕ НА РЕАЛЬНОЕ ХЭШИРОВАНИЕ !!!
            String hashedPassword = password; // Замените на функцию хэширования

            db.collection("users")
                    .whereEqualTo("email", email)
                    .whereEqualTo("passwordHash", hashedPassword)
                    .get()
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            if (task.getResult().isEmpty()) {
                                // Пользователь не найден
                                Toast.makeText(LoginActivity.this, "Неверный email или пароль", Toast.LENGTH_SHORT).show();
                            } else {
                                // Аутентификация успешна!
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    Log.d(TAG, document.getId() + " => " + document.getData());
                                }

                                // Переход на главный экран приложения или другую активность
                                Toast.makeText(LoginActivity.this, "Вход выполнен!", Toast.LENGTH_SHORT).show();
                                // ...
                            }
                        } else {
                            Log.w(TAG, "Ошибка при входе", task.getException());
                            Toast.makeText(LoginActivity.this, "Ошибка входа!", Toast.LENGTH_SHORT).show();
                        }
                    });
        }


    }

